def HappyNumber(n):    
    rem = sum = 0   
    while(n > 0):    
        rem = n%10    
        sum = sum + (rem*rem)    
        n = n//10   
    return sum   
n =int(input("enter a number:"))    
result = n
if(n<=0):
    print("Invalid")
while(result != 1 and result != 4):    
    result = HappyNumber(result)       
if(result == 1):    
    print(str(n) + " is a happy number")   
elif(result == 4):    
    print(str(n) + " is not a happy number")
