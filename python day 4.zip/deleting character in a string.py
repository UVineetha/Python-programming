def remove_char(s1,s2):
    print(s1.replace(s2, ''))
s1 = input("Enter the String : ")
s2 = input("Enter the Character to remove : ")
remove_char(s1,s2)
